TRADING BOT - SMARTPHONE ONLY - FINAL VERSION

1. Open this folder.
2. Hold SHIFT + Right Click inside the folder.
3. Select 'Open PowerShell window here'.

4. Install libraries (type and press enter):
pip install MetaTrader5 pandas numpy matplotlib flask

5. Run the bot (type and press enter):
python trading_bot_webapp.py

6. Find your PC IP by typing in PowerShell:
ipconfig

7. On your smartphone, open your browser and visit:
http://<your-PC-IP>:5000
Example: http://192.168.1.5:5000

8. Fully control the bot from your smartphone:
Start Bot, Stop Bot, Emergency Stop.

Version: 1.0.0
